package com.hospitalmanagement.Controller;

import com.hospitalmanagement.model.Billing;
import com.hospitalmanagement.repository.BillingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/billing")
@CrossOrigin(origins = "http://localhost:5173")
public class BillingController {

    @Autowired
    private BillingRepository repo;

    // Get all bills
    @GetMapping
    public List<Billing> getAllBills() {
        return repo.findAll();
    }

    // Add new bill
    @PostMapping
    public Billing addBill(@RequestBody Billing bill) {
        return repo.save(bill);
    }
}
