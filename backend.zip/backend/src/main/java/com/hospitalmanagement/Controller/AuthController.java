package com.hospitalmanagement.Controller;

import com.hospitalmanagement.model.User;
import com.hospitalmanagement.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:5173") 
public class AuthController {

    @Autowired
    private UserRepository userRepo;

    @PostMapping("/login")
    public String login(@RequestBody User loginUser) {
        User user = userRepo.findByUsername(loginUser.getUsername());
        if (user != null && user.getPassword().equals(loginUser.getPassword())) {
            return "SUCCESS:" + user.getRole();
        } else {
            return "FAIL";
        }
    }
}
