package com.hospitalmanagement.Controller;

import com.hospitalmanagement.model.Patient;
import com.hospitalmanagement.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/patients")
@CrossOrigin(origins = "http://localhost:5173")  	
public class PatientController {

    @Autowired
    private PatientRepository repo;

   
    @GetMapping
    public List<Patient> getAllPatients() {
        return repo.findAll();
    }

   
    @PostMapping
    public Patient addPatient(@RequestBody Patient patient) {
        return repo.save(patient);
    }
}
