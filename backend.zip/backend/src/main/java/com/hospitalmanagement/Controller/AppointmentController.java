package com.hospitalmanagement.Controller;

import com.hospitalmanagement.model.Appointment;
import com.hospitalmanagement.repository.AppointmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/appointments")
@CrossOrigin(origins = "http://localhost:5173") 
public class AppointmentController {

    @Autowired
    private AppointmentRepository repo;

    
    @GetMapping
    public List<Appointment> getAllAppointments() {
        return repo.findAll();
    }

    
    @PostMapping
    public Appointment addAppointment(@RequestBody Appointment appointment) {
        return repo.save(appointment);
    }
}
