package com.hospitalmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hospitalmanagement.model.Doctor;


	public interface DoctorRepository extends JpaRepository<Doctor, Long> {
	}


