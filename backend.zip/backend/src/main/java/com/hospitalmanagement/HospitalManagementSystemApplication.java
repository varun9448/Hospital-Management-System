package com.hospitalmanagement;

import jakarta.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HospitalManagementSystemApplication {

    @Value("${spring.datasource.url:NOT_FOUND}")
    private String dbUrl;

    public static void main(String[] args) {
        SpringApplication.run(HospitalManagementSystemApplication.class, args);
    }

    @PostConstruct
    public void printConfig() {
        System.out.println("👉 Database URL from properties = " + dbUrl);
    }
}
